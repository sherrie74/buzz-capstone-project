<?php
//	CONSTANTS

//	ADD IN VARIABLES FOR DATABASE CALLS
/*	
	define('SALT','$2a$07$AllofOldNothingElseEverEverTriedEverFailed$');
	define('TITLE','SERVICE IQ');
	define('HOST',"http://".$_SERVER['HTTP_HOST']."/");
	define('COPY', "An Ohmal Digital Application &copy;".date("Y"));
	
	// GET THESE FROM DATABASE INSTEAD
	define('MONTHLY_PLAN', "15.00");		// 
	define('QUARTERLY_PLAN', "40.50");
	define('ANNUAL_PLAN',"135.00");
	define('CHO','YOP');
*/
?>