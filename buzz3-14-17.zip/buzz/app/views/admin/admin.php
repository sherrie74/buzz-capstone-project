<?php 

if(!isset($_SESSION['userid']))
{
	header("location:../");
}
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title><?php echo TITLE;?>: Administration</title>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/landing.css"/>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Customer Insight, tagging, mobile, suveys, better business, relationship management">
	<meta name="author" content="John Brenton Phillips">
	<link rel="shortcut icon" href="<?php echo HOST;?>/favicon.ico">

	<style>
		#hello-there{float:right;}
    </style>
</head>

  <body>

    <div class="container">
		<div class="header">
			<ul class="nav nav-pills pull-right">

			</ul>
			<h3 class="text-muted"><span id='mast-header'><?php echo TITLE;?></span>: admin
			<span id='hello-there'><?php echo "Welcome ". $_SESSION['fname'] . " ID: " .$_SESSION['userid'];?></span>
			</h3>
		</div>
		
		<br />
	   	<?php
		include('admin_nav.php');
		?>
      
		<?php 
		//	THE $_SESSION variables URL, SurveyCode, and QRPath WILL BE SET FOR THIS PAGE THROUGH EITHER
		//	SIGNIN OR SIGNUP PROCESS.
		//	HANDLE THE URL / IMAGE BUILD HERE
			//define('RELPATH',dirname($_SERVER['PHP_SELF']));
			if(!defined("SRVHOST"))
			{
				define('SRVHOST',$_SERVER['HTTP_HOST']);
			}
		//	DEFINE URL PATH FOR TESTING
			switch(SRVHOST)
			{
				case "whatsthebuzz":
					$myURLroot = "http://whatsthebuzz";
					$myHTTP = "http://";
				break;
				case "whatsthe.buzz":
					$myURLroot = "https://whatsthe.buzz";
					$myHTTP = "https://";
				break;	
			}
			$urlBUILD = $myURLroot."/for/" . $_SESSION['URL'];
		?>
		
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
		?>
		<div id="multi">
			<form action="" method="post">
				<input type="submit" value="Add Survey" name="newSurvey" />
				<!-- <input type="submit" value="Delete Survey" name="DeleteSurvey" /> -->
			</form>
			
			<?php 
				if(isset($_POST['newSurvey'])) 
				{
					$servername = "localhost";
					$username = "root";
					$password = "";

					// Create connection
					$conn = new mysqli($servername, $username, $password);

					// Check connection
					if ($conn->connect_error) 
					{
						die("Connection failed: " . $conn->connect_error);
					} 
					
					$id = $_SESSION['userid'];
					//$qr = $_SESSION[''];
					//$code = $_SESSION[''];
					
					//Makes new row with new surveyID in multisurvey table
					$sql = "INSERT INTO greatgr2_buzz.multisurvey (userid, QRPath, SurveyCode, couponPath, responseID) VALUES($id, 'whatsthebuzz/qrImages/Wileys_00b5fe6f3be3705d789134ae76ab24f1.png', 'WIL582BA06DE2B78', null, null)";
					
					
					if ($conn->query($sql) === TRUE) 
					{
						echo "New record created successfully in multisurvey";
						echo "<br />";
					} 
					else 
					{
						echo "Error: " . $sql . "<br>" . $conn->error;
					}

					//makes a row with new surveyID in selectedq table
					$sql1 = "INSERT INTO greatgr2_buzz.selectedq (surveyID) SELECT max(surveyID) from greatgr2_buzz.multisurvey where userid=" . $_SESSION['userid'];
					
					//updates the new row make to have default questions chosen
					$sqlfirst = "UPDATE greatgr2_buzz.selectedq SET first=5, second=1, third=6, fourth=10, fifth=3 WHERE surveyID = (select max(surveyID) from greatgr2_buzz.multisurvey where userid=" . $_SESSION['userid'] . ")";
					
					if ($conn->query($sql1) === TRUE) 
					{
						echo "New row created successfully in selectedq";
						echo "<br />";
					} 
					else 
					{
						echo "Error: " . $sql1 . "<br />" . $conn->error;
					}
					if ($conn->query($sqlfirst) === TRUE) 
					{
						echo "New row updated successfully  in selectedq";
						echo "<br />";
					} 
					else 
					{
						echo "Error: " . $sqlfirst . "<br />" . $conn->error;
					}
				}
			?>
		</div>
		<br />
		<div id="surveyNum">
			<p style="font-weight: bold;">The number of surveys under this user is: 
				<?php
					$quest100 = "select count(surveyID) from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
					$result = mysqli_query($conn, $quest100);
										
					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo $row["count(surveyID)"];
						}
					} else {
						echo "0 results";
					}
				?>
			</p>
			
			<p style="font-weight: bold;">Most Recent SurveyID Added: 
				<?php
					$quest100 = "select max(surveyID) from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
					$result = mysqli_query($conn, $quest100);
					$row;
					
					if ($result->num_rows > 0) 
					{
						// output data of each row
						while($row = $result->fetch_assoc()) 
						{
							echo '<p id=' . $row["max(surveyID)"] . '>Survey ID: ';
							echo $row["max(surveyID)"];
							echo '</p>';
						}
					} 
					else 
					{
						echo "0 results";
					}
				?>
			</p>
			
			<p style="font-weight: bold;">Current Surveys under ID <?php echo $_SESSION['userid'];?>: 
				<ul>
					<?php
						$quest100 = "select surveyID from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
						$result = mysqli_query($conn, $quest100);
											
						if ($result->num_rows > 0) {
							// output data of each row
							while($row = $result->fetch_assoc()) {
								echo '<li id=' . $row["surveyID"] . '>';
								echo $row["surveyID"];
								echo '</li>';
							}
						} else {
							echo "0 results";
						}
					?>
				</ul>
			</p>
		</div>
		
		<hr />
		
    	<h3>Your URL: <input style="width:100%;" type="text" value="<?php echo $urlBUILD;?>"></h3>

		<table>
			<tr>
				<td style="border-right: #D5D8DC solid 1px;">
					<h3>Your Survey Code: <input style="width:100%;" type="text" value="<?php echo $_SESSION['uniqueID'];?>"></h3>
					<h3>Your QR Code:<br>
						<img id='qrImage2' style="width:50%;height:50%" src='<?php echo $myHTTP.$_SESSION['QRPath'];?>'>&nbsp;
					</h3>
				</td>
				
				<td style="width: 50%">
					<h3>Current Survey Questions:</h3>
					<ul style="font-size: 12pt">
						<?php
							//displays current questions chosen for one survey only
							//FIX - LET USER CHOOSE WHICH QUESTIONS ARE DISPLAYED?
							$quest1 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.first where greatgr2_buzz.selectedq.surveyID = 1";
							
							$quest2 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.second where greatgr2_buzz.selectedq.surveyID = 1";
							
							$quest3 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.third where greatgr2_buzz.selectedq.surveyID = 1";
							
							$quest4 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.fourth where greatgr2_buzz.selectedq.surveyID = 1";
							
							$quest5 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.fifth where greatgr2_buzz.selectedq.surveyID = 1";
							
							$result1 = mysqli_query($conn, $quest1);
							$result2 = mysqli_query($conn, $quest2);
							$result3 = mysqli_query($conn, $quest3);
							$result4 = mysqli_query($conn, $quest4);
							$result5 = mysqli_query($conn, $quest5);
							
							
							if ($result1->num_rows > 0) 
							{
								// output data of each row
								while($row = $result1->fetch_assoc()) 
								{
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} 
							else 
							{
								echo "0 results";
							}
							
							if ($result2->num_rows > 0) 
							{
								// output data of each row
								while($row = $result2->fetch_assoc()) 
								{
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} 
							else 
							{
								echo "0 results";
							}
							
							if ($result3->num_rows > 0) 
							{
								// output data of each row
								while($row = $result3->fetch_assoc()) 
								{
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} 
							else 
							{
								echo "0 results";
							}
							
							if ($result4->num_rows > 0) 
							{
								// output data of each row
								while($row = $result4->fetch_assoc()) 
								{
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} 
							else 
							{
								echo "0 results";
							}
							
							if ($result5->num_rows > 0) 
							{
								// output data of each row
								while($row = $result5->fetch_assoc()) 
								{
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} 
							else 
							{
								echo "0 results";
							}
						?>
					</ul>
				</td>
			</tr>
		</table>
		
		<hr />
		
		<div name="custom">
			<h3>Customize Survey - Pick the questions you want to use for your surveys.</h3>
			
			<form action="" method="post">
				<p>Enter the ID number of the survey you want to update: 
					<input type="text" name="ChooseSurv" id="CSurv" maxlength="2" />
				</p>
				
				<p>Question 1: 
					<select id="first" name="first">
						<option value="1" id="01">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 1;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="2" id="02">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 2;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<p>Question 2: 
					<select id="second" name="second">
						<option value="3" id="03">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 3;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="4" id="04">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 4;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<p>Question 3: 
					<select id="third" name="third">
						<option value="5" id="05">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 5;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="6" id="06">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 6;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<p>Question 4: 
					<select id="fourth" name="fourth">
						<option value="7" id="07">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 7;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="8" id="08">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 8;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<p>Question 5: 
					<select id="fifth" name="fifth">
						<option value="9" id="09">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 9;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="10" id="10">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 10;";
							$result = mysqli_query($conn, $quest100);
							$meow = $result;
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
			<input type="submit" name="TestSub" value="Submit"/>
			</form>	
			
			<?php 
			//updates the survey questions depending on which survey the user chooses
			if(isset($_POST['TestSub'])) 
			{
				$servername = "localhost";
				$username = "root";
				$password = "";

				// Create connection
				$conn = new mysqli($servername, $username, $password);

				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
				
				$UpdateSurvey = $_POST['ChooseSurv'];
				
				$info1 = $_POST['first'];
				$info2 = $_POST['second'];
				$info3 = $_POST['third'];
				$info4 = $_POST['fourth'];
				$info5 = $_POST['fifth'];
				
				$sql = "UPDATE greatgr2_buzz.selectedq SET first=$info1, second=$info2, third=$info3, fourth=$info4, fifth=$info5 where surveyID='$UpdateSurvey'";
				
				if ($conn->query($sql) === TRUE) 
				{
					echo "Record updated successfully <br />";
				} 
				else 
				{
					echo "Error: " . $sql . "<br />" . $conn->error;
				}
			}
			?>					
		</div>
		
		<br />
		<br />
		<br />
		<br />
		<br />

		<div class="navbar navbar-fixed-bottom survey-footer" >
			<p><?php echo COPY;?> | <a href="../logout">logout</a></p>
		</div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="<?php echo HOST;?>/js/pubnav.js"></script>
<?php $conn->close();?>
	</body>
</html>