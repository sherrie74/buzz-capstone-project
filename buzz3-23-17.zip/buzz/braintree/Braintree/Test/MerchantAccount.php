<?php
/**
 * Merchant Account constants used for testing purposes
 *
 * @package    Braintree
 * @subpackage Test
 * @copyright  2013 Braintree Payment Solutions
 */
class Braintree_Test_MerchantAccount
{
    public static $approve = "approve_me";
}
