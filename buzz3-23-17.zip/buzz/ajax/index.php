<?php
header("location:../");
?>