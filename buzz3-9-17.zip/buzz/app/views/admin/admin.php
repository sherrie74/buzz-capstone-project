<?php 

if(!isset($_SESSION['userid']))
{
	header("location:../");
}
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title><?php echo TITLE;?>: Administration</title>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/landing.css"/>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Customer Insight, tagging, mobile, suveys, better business, relationship management">
	<meta name="author" content="John Brenton Phillips">
	<link rel="shortcut icon" href="<?php echo HOST;?>/favicon.ico">

	<style>
		#hello-there{float:right;}
    </style>
</head>

  <body>

    <div class="container">
		<div class="header">
			<ul class="nav nav-pills pull-right">

			</ul>
			<h3 class="text-muted"><span id='mast-header'><?php echo TITLE;?></span>: admin
			<span id='hello-there'><?php echo "Welcome ". $_SESSION['fname'] . " ID: " .$_SESSION['userid'];?></span>
			</h3>
		</div>
		
		<br />
	   	<?php
		include('admin_nav.php');
		?>
      
		<?php 
			//	THE $_SESSION variables URL, SurveyCode, and QRPath WILL BE SET FOR THIS PAGE THROUGH EITHER
			//	SIGNIN OR SIGNUP PROCESS.
			//	HANDLE THE URL / IMAGE BUILD HERE
				//define('RELPATH',dirname($_SERVER['PHP_SELF']));
				if(!defined("SRVHOST"))
				{
					define('SRVHOST',$_SERVER['HTTP_HOST']);
				}
			//	DEFINE URL PATH FOR TESTING
				switch(SRVHOST)
				{
					case "whatsthebuzz":
						$myURLroot = "http://whatsthebuzz";
						$myHTTP = "http://";
					break;
					case "whatsthe.buzz":
						$myURLroot = "https://whatsthe.buzz";
						$myHTTP = "https://";
					break;	
				}
				$urlBUILD = $myURLroot."/for/" . $_SESSION['URL'];
				
		?>
		
		<?php
			$servername = "localhost";
			$username = "root";
			$password = "";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
		?>
		<div id="multi">
			<form action="" method="post">
				<input type="button" value="Add Survey" name="newSurvey" />
			</form>
			
			<?php 
			if(isset($_POST['newSurvey'])) 
			{
					$servername = "localhost";
					$username = "root";
					$password = "";

					// Create connection
					$conn = new mysqli($servername, $username, $password);

					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					} 
					
					//$info = $_POST['fifth'];
					
					$sql = "INSERT INTO greatgr2_buzz.multisurvey(userid, busname, logoPath, QRPath, SurveyCode, couponPath, responseID) VALUES(106, null, null, null, null,null,null);";
					
					
					if ($conn->query($sql) === TRUE) {
						echo "New record created successfully";
					} else {
						echo "Error: " . $sql . "<br>" . $conn->error;
							}
			}
			?>
		</div>
		<br />
		<div id="surveyNum">
			<p style="font-weight: bold;">The number of surveys under this user is: 
				<?php
					$quest100 = "select count(surveyID) from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
					$result = mysqli_query($conn, $quest100);
										
					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo $row["count(surveyID)"];
						}
					} else {
						echo "0 results";
					}
				?>
			</p>
			<p style="font-weight: bold;">Current Surveys under ID <?php echo $_SESSION['userid'];?>: 
				<ul>
					<?php
						$quest100 = "select surveyID from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
						$result = mysqli_query($conn, $quest100);
											
						if ($result->num_rows > 0) {
							// output data of each row
							while($row = $result->fetch_assoc()) {
								echo '<li>';
								echo $row["surveyID"];
								echo '</li>';
							}
						} else {
							echo "0 results";
						}
					?>
				</ul>
			</p>
		</div>
		
    	<h3>Your URL: <input style="width:100%;" type="text" value="<?php echo $urlBUILD;?>"></h3>

		<table>
			<tr>
				<td style="border-right: #D5D8DC solid 1px;">
					<h3>Your Survey Code: <input style="width:100%;" type="text" value="<?php echo $_SESSION['uniqueID'];?>"></h3>
					<h3>Your QR Code:<br>
						<img id='qrImage2' style="width:50%;height:50%" src='<?php echo $myHTTP.$_SESSION['QRPath'];?>'>&nbsp;
					</h3>
				</td>
				
				<td style="width: 50%">
					<h3>Current Survey Questions:</h3>
					<ul style="font-size: 12pt">
						<?php
							$quest100 = "select PossQuestion from greatgr2_buzz.selectedq
							inner join greatgr2_buzz.questions
							on greatgr2_buzz.selectedq.qID = greatgr2_buzz.questions.qID";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo '<li>';
									echo $row["PossQuestion"];
									echo '</li>';
								}
							} else {
								echo "0 results";
							}
						?>
					</ul>
				</td>
			</tr>
		</table>
		
		<hr />
		
		<div name="custom">
			<h3>Customize Survey - Pick the questions you want to use for your surveys.</h3>
			
			<form action="" method="post">
				<p>Question 1: 
					<select id="first" name="first">
						<option value="1" id="01">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 1;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="2" id="02">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 2;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<?php 
					if(isset($_POST['firstSub'])) 
					{

							$servername = "localhost";
							$username = "root";
							$password = "";

							// Create connection
							$conn = new mysqli($servername, $username, $password);

							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 
							$info = $_POST['first'];
							$sql = "UPDATE greatgr2_buzz.selectedq SET qID=$info WHERE SelQSpot='first'";
							if ($conn->query($sql) === TRUE) {
								echo "New record created successfully";
							} else {
								echo "Error: " . $sql . "<br>" . $conn->error;
									}
					}
				?>
				
				<p>Question 2: 
					<select id="second" name="second">
						<option value="3" id="03">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 3;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="4" id="04">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 4;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<?php 
					if(isset($_POST['secondSub'])) 
					{

							$servername = "localhost";
							$username = "root";
							$password = "";

							// Create connection
							$conn = new mysqli($servername, $username, $password);

							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 
							$info = $_POST['second'];
							$sql = "UPDATE greatgr2_buzz.selectedq SET qID=$info WHERE SelQSpot='second'";
							if ($conn->query($sql) === TRUE) {
								echo "New record created successfully";
							} else {
								echo "Error: " . $sql . "<br>" . $conn->error;
									}
					}
				?>
				
				<p>Question 3: 
					<select id="third" name="third">
						<option value="5" id="05">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 5;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="6" id="06">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 6;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<?php 
					if(isset($_POST['thirdSub'])) 
					{

							$servername = "localhost";
							$username = "root";
							$password = "";

							// Create connection
							$conn = new mysqli($servername, $username, $password);

							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 
							$info = $_POST['third'];
							$sql = "UPDATE greatgr2_buzz.selectedq SET qID=$info WHERE SelQSpot='third'";
							if ($conn->query($sql) === TRUE) {
								echo "New record created successfully";
							} else {
								echo "Error: " . $sql . "<br>" . $conn->error;
									}
					}
				?>
				
				<p>Question 4: 
					<select id="fourth" name="fourth">
						<option value="7" id="07">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 7;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="8" id="08">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 8;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
				
				<?php 
					if(isset($_POST['fourthSub'])) 
					{

							$servername = "localhost";
							$username = "root";
							$password = "";

							// Create connection
							$conn = new mysqli($servername, $username, $password);

							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							} 
							$info = $_POST['fourth'];
							$sql = "UPDATE greatgr2_buzz.selectedq SET qID=$info WHERE SelQSpot='fourth'";
							if ($conn->query($sql) === TRUE) {
								echo "New record created successfully";
							} else {
								echo "Error: " . $sql . "<br>" . $conn->error;
									}
					}
				?>
				
				<p>Question 5: 
					<select id="fifth" name="fifth">
						<option value="9" id="09">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 9;";
							$result = mysqli_query($conn, $quest100);
												
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
						<option value="10" id="10">
						<?php
							$quest100 = "Select * from greatgr2_buzz.questions where qID = 10;";
							$result = mysqli_query($conn, $quest100);
							$meow = $result;
							
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									echo $row["PossQuestion"];
								}
							} else {
								echo "0 results";
							}
						?>
						</option>
					</select>
				</p>
			<input type="submit" name="TestSub" value="Submit"/>
			</form>	
			
			<?php 
			if(isset($_POST['TestSub'])) 
			{
				$servername = "localhost";
				$username = "root";
				$password = "";

				// Create connection
				$conn = new mysqli($servername, $username, $password);

				// Check connection
				if ($conn->connect_error) {
					die("Connection failed: " . $conn->connect_error);
				} 
				
				$info1 = $_POST['first'];
				$sql1 = "UPDATE greatgr2_buzz.selectedq SET qID=$info1 WHERE SelQSpot='first'";
				
				$info2 = $_POST['second'];
				$sql2 = "UPDATE greatgr2_buzz.selectedq SET qID=$info2 WHERE SelQSpot='second'";
				
				$info3 = $_POST['third'];
				$sql3 = "UPDATE greatgr2_buzz.selectedq SET qID=$info3 WHERE SelQSpot='third'";
				
				$info4 = $_POST['fourth'];
				$sql4 = "UPDATE greatgr2_buzz.selectedq SET qID=$info4 WHERE SelQSpot='fourth'";
				
				$info5 = $_POST['fifth'];
				$sql5 = "UPDATE greatgr2_buzz.selectedq SET qID=$info5 WHERE SelQSpot='fifth'";
				
				
				if ($conn->query($sql1) === TRUE) 
				{
					echo "New record created successfully <br>";
				} 
				else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
						
				if ($conn->query($sql2) === TRUE) 
				{
					echo "New record created successfully <br>";
				} 
				else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
						
				if ($conn->query($sql3) === TRUE) 
				{
					echo "New record created successfully <br>";
				} 
				else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
						
				if ($conn->query($sql4) === TRUE) 
				{
					echo "New record created successfully <br>";
				} 
				else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
						
				if ($conn->query($sql5) === TRUE) 
				{
					echo "New record created successfully <br>";
				} 
				else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
			}
			?>					
		</div>
		
		<br />
		<br />
		<br />
		<br />
		<br />

		<div class="navbar navbar-fixed-bottom survey-footer" >
			<p><?php echo COPY;?> | <a href="../logout">logout</a></p>
		</div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="<?php echo HOST;?>/js/pubnav.js"></script>
<?php $conn->close();?>
	</body>
</html>