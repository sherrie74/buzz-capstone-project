<?php
/*
	Pink 	#f02979	(240,41,121)
	Green 	#32b655	(50,182,85)
	Orange 	#ffcc00	(255,180,1)
	Blue 	#00a8cc	(0,168,204)
	Grey		#545454	(84,84,84)
*/

?>

<style>
.WhatsThe{color:#545454;font-size:1.4em;}
.Buzz{color:#ffcc00;font-size:1.4em;}
.framed{border:0px;background-image:url(<?php echo HOST;?>img/honeycomb-title.png);background-repeat:no-repeat;background-size:60px 60px;}
</style>
<h3 class="text-muted framed">
	<span class='myHeader' id='mast-header'>
		<span class="WhatsThe">WhatsThe</span><span class="Buzz">.Buzz</span>
	</span>
</h3>