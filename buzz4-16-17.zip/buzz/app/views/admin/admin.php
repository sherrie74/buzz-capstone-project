<?php 

if(!isset($_SESSION['userid']))
{
	header("location:../");
}
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title><?php echo TITLE;?>: Administration</title>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo HOST;?>bootstrap/css/landing.css"/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Customer Insight, tagging, mobile, suveys, better business, relationship management">
	<meta name="author" content="John Brenton Phillips">
	<link rel="shortcut icon" href="<?php echo HOST;?>/favicon.ico">

	<style>
		#hello-there{float:right;}
    </style>
</head>

<body>
    <div class="container">
		<div class="header">
			<ul class="nav nav-pills pull-right">

			</ul>
			<h3 class="text-muted"><span id='mast-header'><?php echo TITLE;?></span>: admin
			<span id='hello-there'><?php echo "Welcome ". $_SESSION['fname'] . " ID: " .$_SESSION['userid'];?></span>
			</h3>
		</div>
		
	   	<?php
		include('admin_nav.php');
		?>
      
		<?php 
		//	THE $_SESSION variables URL, SurveyCode, and QRPath WILL BE SET FOR THIS PAGE THROUGH EITHER
		//	SIGNIN OR SIGNUP PROCESS.
		//	HANDLE THE URL / IMAGE BUILD HERE
			//define('RELPATH',dirname($_SERVER['PHP_SELF']));
			if(!defined("SRVHOST"))
			{
				define('SRVHOST',$_SERVER['HTTP_HOST']);
			}
		//	DEFINE URL PATH FOR TESTING
			switch(SRVHOST)
			{
				case "whatsthebuzz":
					$myURLroot = "http://whatsthebuzz";
					$myHTTP = "http://";
				break;
				case "whatsthe.buzz":
					$myURLroot = "https://whatsthe.buzz";
					$myHTTP = "https://";
				break;	
			}
			$urlBUILD = $myURLroot."/for/" . $_SESSION['URL'];
		?>
		
		<?php //starts connection with DB
			$servername = "localhost";
			$username = "root";
			$password = "";

			// Create connection
			$conn = new mysqli($servername, $username, $password);

			// Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			} 
		?>
		
		<div id="multi">
			<table style="width: 100%">
				<tr>
					<td align="center" colspan="2" style="border-bottom: #D5D8DC dashed 1px; border-top: #D5D8DC dashed 1px;">
						<h3>Your base URL: <?php echo $urlBUILD;?></h3>
						<div id="surveyNum">
							<h4 style="font-weight: bold;">The number of surveys under this user is: 
								<?php
									$quest100 = "select count(surveyID) from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
									$result = mysqli_query($conn, $quest100);
														
									if ($result->num_rows > 0) {
										// output data of each row
										while($row = $result->fetch_assoc()) {
											echo $row["count(surveyID)"];
										}
									} else {
										echo "0 results";
									}
								?>
							</h4>
						</div>
					</td>
				</tr>

				<tr style="border-bottom: #D5D8DC dashed 1px;">
					<td style="border-top: #D5D8DC dashed 1px;">
						<h3>Your Survey Codes: </h3>
						<h5>Click on the numbers below to open up the current question section and the QR code section.</h5>
						<ul style="font-size: 12pt">
							<?php 
								$quest100 = "select * from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
									
								$result = mysqli_query($conn, $quest100);
													
								if ($result->num_rows > 0) 
								{
									// output data of each row
									while($row = $result->fetch_assoc()) 
									{
										
										echo '<li>';
										echo '<a data-toggle="collapse" data-target=".' . $row["surveyID"] . '">';
										echo '#' . $row["surveyID"];
										echo '</a>';
										echo '</li>';
										
									}
								} 
								else 
								{
									echo "0 results";
								}
							?>
						</ul>
					</td>
					
					<td style="width: 50%; border-top: #D5D8DC dashed 1px;">
						<h3>Current Survey Questions:</h3>
						<ul style="font-size: 12pt">
							<?php
								//displays current questions chosen for one survey only
								//FIX - LET USER CHOOSE WHICH QUESTIONS ARE DISPLAYED?'
								
								$questMain = "select * from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
								$resultMain = mysqli_query($conn, $questMain);
													
								if ($resultMain->num_rows > 0) 
								{
									// output data of each row
									while($row = $resultMain->fetch_assoc()) 
									{
										$quest1 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.first where greatgr2_buzz.selectedq.surveyID =" . $row["surveyID"];
								
										$quest2 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.second where greatgr2_buzz.selectedq.surveyID =" . $row["surveyID"];
										
										$quest3 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.third where greatgr2_buzz.selectedq.surveyID =" . $row["surveyID"];
										
										$quest4 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.fourth where greatgr2_buzz.selectedq.surveyID =" . $row["surveyID"];
										
										$quest5 = "select PossQuestion from greatgr2_buzz.questions inner join greatgr2_buzz.selectedq on greatgr2_buzz.questions.qID = greatgr2_buzz.selectedq.fifth where greatgr2_buzz.selectedq.surveyID =" . $row["surveyID"];
										
										$result1 = mysqli_query($conn, $quest1);
										$result2 = mysqli_query($conn, $quest2);
										$result3 = mysqli_query($conn, $quest3);
										$result4 = mysqli_query($conn, $quest4);
										$result5 = mysqli_query($conn, $quest5);
										
										echo '<div class="' . $row["surveyID"] . ' collapse">';
										echo '#' . $row["surveyID"];
										
										if ($result1->num_rows > 0) 
										{
											// output data of each row
											while($row = $result1->fetch_assoc()) 
											{
												//echo '<div class="' . $row["surveyID"] . '">';
												echo '<li>';
												echo $row["PossQuestion"];
												echo '</li>';
											}
										} 
										else 
										{
											echo "0 results";
										}
										
										if ($result2->num_rows > 0) 
										{
											// output data of each row
											while($row = $result2->fetch_assoc()) 
											{
												echo '<li>';
												echo $row["PossQuestion"];
												echo '</li>';
											}
										} 
										else 
										{
											echo "0 results";
										}
										
										if ($result3->num_rows > 0) 
										{
											// output data of each row
											while($row = $result3->fetch_assoc()) 
											{
												echo '<li>';
												echo $row["PossQuestion"];
												echo '</li>';
											}
										} 
										else 
										{
											echo "0 results";
										}
										
										if ($result4->num_rows > 0) 
										{
											// output data of each row
											while($row = $result4->fetch_assoc()) 
											{
												echo '<li>';
												echo $row["PossQuestion"];
												echo '</li>';
											}
										} 
										else 
										{
											echo "0 results";
										}
										
										if ($result5->num_rows > 0) 
										{
											// output data of each row
											while($row = $result5->fetch_assoc()) 
											{
												echo '<li>';
												echo $row["PossQuestion"];
												echo '</li>';
											}
										} 
										else 
										{
											echo "0 results";
										}
										
										echo '</div>';
									}
								} 
								else 
								{
									echo "0 results";
								}
							?>
						</ul>
						
						<h3>Your QR Code: </h3>
						<ul style="font-size: 12pt">
							<?php
								//displays current questions chosen for one survey only
								//FIX - LET USER CHOOSE WHICH QUESTIONS ARE DISPLAYED?'
								
								$questMain = "select * from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
								$resultMain = mysqli_query($conn, $questMain);
													
								if ($resultMain->num_rows > 0) 
								{
									// output data of each row
									while($row = $resultMain->fetch_assoc()) 
									{
										$quest2 = "select * from greatgr2_buzz.multisurvey where greatgr2_buzz.multisurvey.surveyID =" . $row["surveyID"];

										$result2 = mysqli_query($conn, $quest2);
										
										echo '<div class="' . $row["surveyID"] . ' collapse">';
										echo '#' . $row["surveyID"];

										if ($result2->num_rows > 0) 
										{
											// output data of each row
											while($row = $result2->fetch_assoc()) 
											{
												//echo '<div class="' . $row["surveyID"] . '">';
												echo '<br />';
												//DELETE ECHO
												//echo $row["QRPath"];
												echo '<img src="qrimages/Wileys_00b5fe6f3be3705d789134ae76ab24f1.png" alt="QR Image" height="250" width="250" />';
											}
										} 
										else 
										{
											echo "0 results";
										}	

										echo '</div>';
									}
								} 
								else 
								{
									echo "0 results";
								}
							?>
						</ul>
					</td>
				</tr>

				<tr>
					<td colspan="2">
						<?php
							//makes a new variable for the qr handler function

							$NewSurveyNumber = "SELECT max(surveyID) from greatgr2_buzz.multisurvey where userid=" . $_SESSION['userid'];

							$resultNewSurveyNumber = mysqli_query($conn, $NewSurveyNumber);
												
							if ($resultNewSurveyNumber->num_rows > 0) 
							{
								// output data of each row
								while($row = $resultNewSurveyNumber->fetch_assoc())
								{
									$NewSurveyNumberURL = $row["max(surveyID)"];
									$NewURLBuild = $myURLroot."/for/" . $_SESSION['URL'] . "/" . $NewSurveyNumberURL;
									//echo '<div id="URLUpdate">';
									echo '<h4 style="text-align: center">The URL for the most recent survey is: <span style="font-weight: bold"> ';
									echo $NewURLBuild;
									echo '</span></h4>';
									//echo '</span></div>';
								}
							}
							else 
							{
								echo "0 results";
							}
						?>

						<form action="" method="post">
							<div id="buttons" style="text-align: center;">
								<input type="submit" value="Add Survey" name="newSurvey" />
								<input type="submit" value="Delete Survey ID#:" name="deleteSurvey" />
								<input type="submit" name="UpSub" value="Update Survey" />
								<input type="submit" value="Add a QR to the newest Survey" name="QRUpdate" />
							</div>

							<div id="RadioSurv">
								<p style="text-align: center;">Survey ID: 
									<?php //shows radio buttons
										$quest100 = "select surveyID from greatgr2_buzz.multisurvey where userid=" .$_SESSION['userid'];
										
										$result = mysqli_query($conn, $quest100);
										
										if ($result->num_rows > 0) 
										{
											// output data of each row
											while($row = $result->fetch_assoc()) 
											{
												echo '<input type="radio" name="RadioSurv" id="' . $row["surveyID"] . '" value="' . $row["surveyID"] . '" />';
												echo '#' . $row["surveyID"] . '&nbsp;';
												
											}
										} 
										else 
										{
											echo "0 results";
										}
									?>
								</p>

								<h3>Customize Survey - Pick the questions you want to use for your surveys.</h3>
								<p>Pick which survey you want to update: </p>
								
								<p>Question 1: 
									<select id="first" name="first">
										<option value="1" id="01">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 1;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
										<option value="2" id="02">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 2;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
									</select>
								</p>
								
								<p>Question 2: 
									<select id="second" name="second">
										<option value="3" id="03">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 3;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
										<option value="4" id="04">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 4;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
									</select>
								</p>
								
								<p>Question 3: 
									<select id="third" name="third">
										<option value="5" id="05">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 5;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
										<option value="6" id="06">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 6;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
									</select>
								</p>
								
								<p>Question 4: 
									<select id="fourth" name="fourth">
										<option value="7" id="07">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 7;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
										<option value="8" id="08">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 8;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
									</select>
								</p>
								
								<p>Question 5: 
									<select id="fifth" name="fifth">
										<option value="9" id="09">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 9;";
											$result = mysqli_query($conn, $quest100);
																
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
										<option value="10" id="10">
										<?php
											$quest100 = "Select * from greatgr2_buzz.questions where qID = 10;";
											$result = mysqli_query($conn, $quest100);
											$meow = $result;
											
											if ($result->num_rows > 0) {
												// output data of each row
												while($row = $result->fetch_assoc()) {
													echo $row["PossQuestion"];
												}
											} else {
												echo "0 results";
											}
										?>
										</option>
									</select>
								</p>
							</div>

							<!-- ADDS QR CODE - TEST -->
							<?php
								function handleQR($imgpath, $urlpath, $surveyNum)
								{
									//MAKE THIS AJAX
									//WHEN BUTTON IS SHOWN THEN GATHER THE DATA
									//ON ONCLICK HAVE THE FUNCTION HAPPEN
									switch(SRVHOST)
									{
										case "whatsthebuzz":
										//	define('TEMPPATH','/Library/WebServer/wwwroot/greenolive/qrImage'.DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR);
										//define('TEMPPATH','/Library/WebServer/wwwroot/buzz/qrImages'.DIRECTORY_SEPARATOR);
										define('TEMPPATH','/qrimages'.DIRECTORY_SEPARATOR);		
										break;
										case "whatsthe.buzz":
										//	NEED TO SEE WHAT THIS ENDS UP BEING - ycloser1 won't be the user name for this site
										define('TEMPPATH','/home/greatgr2/public_html/qrImages'.DIRECTORY_SEPARATOR);
										break;
									
									}   
								    	//	set it to writable location, a place for temp generated PNG files
								    		$PNG_TEMP_DIR = TEMPPATH;
								    
								    	// 	html PNG location prefix
								    		$PNG_WEB_DIR = 'qrImages/';      
								    
								    	//	of course we need rights to create temp dir
								    		if (!file_exists($PNG_TEMP_DIR))
								        	mkdir($PNG_TEMP_DIR);
									//	echo $PNG_TEMP_DIR
								    		$filename = "";
								    		$filename = SRVHOST."/qrImages/".$imgpath . $surveyNum.'.png';
								    
								    	//	processing form input
								    	//	remember to sanitize user input in real-life solution !!!
								    		$errorCorrectionLevel = 'H';
								    
								    		/*if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
								        	$errorCorrectionLevel = $_REQUEST['level'];   */ 

								    		$matrixPointSize = 7;
								    
									    /*
									    if (isset($_REQUEST['size']))
										   $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);
										*/

								    		if (isset($urlpath)) { 
								    
								        		//	it's very important!
								        			if (trim($urlpath) == '')
								           		echo "Error"; 
										  
										  	//	die('data cannot be empty! <a href="?">back</a>');
								            
									// 	user data
									   	$buildpath = $PNG_TEMP_DIR;
										$addImage =  $imgpath."_".md5($urlpath.'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
								        	$filename = $buildpath.$addImage;
									   	QRcode::png($urlpath, $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
								        
								    } 
								        
								    	//	display generated file
								    	//	echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" /><hr/>';
										return $myHTTP . SRVHOST ."/qrImages/$addImage";
								}
							?>
							<!-- UPDATES SURVEY -->
							<?php 
								if(isset($_POST['UpSub'])) 
								{
									$info1 = $_POST['first'];
									$info2 = $_POST['second'];
									$info3 = $_POST['third'];
									$info4 = $_POST['fourth'];
									$info5 = $_POST['fifth'];
									$radio = $_POST['RadioSurv'];
									
									$sql = "UPDATE greatgr2_buzz.selectedq SET first=$info1, second=$info2, third=$info3, fourth=$info4, fifth=$info5 where surveyID='$radio'";
									
									if ($conn->query($sql) === TRUE) 
									{
										echo "Record updated successfully <br />";
										echo "<meta http-equiv='refresh' content='0'>";
									} 
									else 
									{
										echo "Error: " . $sql . "<br />" . $conn->error;
									}
								}
							?>

							<!-- DELETES SURVEY -->
							<?php
								if(isset($_POST['deleteSurvey'])) 
								{
									$id = $_SESSION['userid'];
									$radioDel = $_POST['RadioSurv'];
									
									//Deletes row from multisurvey where surveyID was chosen
									$sql = "DELETE FROM greatgr2_buzz.multisurvey WHERE surveyID = '$radioDel'";
									
									if ($conn->query($sql) === TRUE) 
									{
										//echo "<br />";
										//echo "Record successfully deleted from multisurvey";
										//echo "<br />";
									} 
									else 
									{
										echo "Error: " . $sql . "<br>" . $conn->error;
									}

									//Deletes row from selectedq where surveyID was chosen
									$sql1 = "DELETE FROM greatgr2_buzz.selectedq WHERE surveyID = '$radioDel'";
									
									if ($conn->query($sql1) === TRUE) 
									{
										//echo "Record successfully from selectedq";
										//echo "<br />";
										echo "<meta http-equiv='refresh' content='0'>";
									} 
									else 
									{
										echo "Error: " . $sql1 . "<br />" . $conn->error;
									}
								}
							?>

							<!-- ADDS QR CODE/IMAGE -->
							<?php 
								if(isset($_POST['QRUpdate'])) 
								{
									echo 'the call works';

									$newQrImage = handleQR($_SESSION['URL'],$NewURLBuild,$NewSurveyNumberURL);
									$_SESSION['QRPath'] = $newQrImage;

									echo $newQrImage;
								}
							?>

							<!-- ADDS NEW SURVEY -->
							<?php 
								if(isset($_POST['newSurvey'])) 
								{
									$id = $_SESSION['userid'];
									//$qr = $_SESSION[''];
									//$code = $_SESSION[''];
									
									//Makes new row with new surveyID in multisurvey table
									$sql = "INSERT INTO greatgr2_buzz.multisurvey (userid, QRPath, SurveyCode, couponPath, responseID) VALUES($id, 'whatsthebuzz/qrImages/Wileys_00b5fe6f3be3705d789134ae76ab24f1.png', 'WIL582BA06DE2B78', null, null)";
									
									
									if ($conn->query($sql) === TRUE) 
									{
										//echo "New record created successfully in multisurvey";
										//echo "<br />";
									} 
									else 
									{
										echo "Error: " . $sql . "<br>" . $conn->error;
									}

									//makes a row with new surveyID in selectedq table

									$sql1 = "INSERT INTO greatgr2_buzz.selectedq (surveyID) SELECT max(surveyID) from greatgr2_buzz.multisurvey where userid=" . $_SESSION['userid'];
									
									//updates the new row make to have default questions chosen
									$sqlfirst = "UPDATE greatgr2_buzz.selectedq SET first=5, second=1, third=6, fourth=10, fifth=3 WHERE surveyID = (select max(surveyID) from greatgr2_buzz.multisurvey where userid=" . $_SESSION['userid'] . ")";

									if ($conn->query($sql1) === TRUE) 
									{
										//echo "New row created successfully in selectedq";
										//echo "<br />";
									} 
									else 
									{
										echo "Error: " . $sql1 . "<br />" . $conn->error;
									}

									if ($conn->query($sqlfirst) === TRUE) 
									{
										//echo "New row updated successfully  in selectedq";
										//echo "<br />";
										//echo "<meta http-equiv='refresh' content='0'>";
									} 
									else 
									{
										echo "Error: " . $sqlfirst . "<br />" . $conn->error;
									}
								}
							?>
						</form>
					</td>
				</tr>
			</table>
				
		</div>
		
		<hr />
		
		<br />
		<br />
		<br />
		<br />
		<br />

		<div class="navbar navbar-fixed-bottom survey-footer" >
			<p><?php echo COPY;?> | <a href="../logout">logout</a></p>
		</div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="<?php echo HOST;?>/js/pubnav.js"></script>
<?php 
	$conn->close();
?>
	</body>
</html>